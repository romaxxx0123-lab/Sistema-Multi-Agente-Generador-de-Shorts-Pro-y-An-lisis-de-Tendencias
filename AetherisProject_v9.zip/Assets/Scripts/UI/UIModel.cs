using UnityEngine;

namespace Company.Games.UI
{
    public abstract class UIModel : ScriptableObject
    {
        public System.Action OnDataChanged;
        protected void NotifyChange() => OnDataChanged?.Invoke();
    }
}