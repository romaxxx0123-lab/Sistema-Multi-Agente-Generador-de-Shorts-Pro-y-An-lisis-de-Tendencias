using UnityEngine;

namespace Company.Games.UI
{
    public abstract class UIPresenter<TView, TModel> : MonoBehaviour 
        where TView : UIView 
        where TModel : UIModel
    {
        [SerializeField] protected TView view;
        [SerializeField] protected TModel model;

        protected virtual void OnEnable()
        {
            model.OnDataChanged += Refresh;
            Refresh();
        }

        protected virtual void OnDisable() => model.OnDataChanged -= Refresh;
        protected abstract void Refresh();
    }
}