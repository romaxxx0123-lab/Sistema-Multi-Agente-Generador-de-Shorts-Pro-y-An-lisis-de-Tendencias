using UnityEngine;
using UnityEngine.Events;

namespace Company.Games.Gameplay
{
    public class Interactable : MonoBehaviour
    {
        public UnityEvent onInteract;
        public float interactDistance = 2.0f;

        public void Interact()
        {
            onInteract.Invoke();
            Debug.Log("Interacted with " + gameObject.name);
        }
    }
}