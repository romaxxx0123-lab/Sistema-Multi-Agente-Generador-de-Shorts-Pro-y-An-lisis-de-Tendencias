using UnityEngine;

namespace Company.Games.ScriptableArchitecture
{
    [CreateAssetMenu(fileName = "New bool Variable", menuName = "Architecture/Variables/bool")]
    public class boolVariable : ScriptableObject
    {
        public bool Value;
        public void SetValue(bool value) => Value = value;
        public void SetValue(boolVariable value) => Value = value.Value;
    }
}