using UnityEngine;

namespace Company.Games.ScriptableArchitecture
{
    [CreateAssetMenu(fileName = "New float Variable", menuName = "Architecture/Variables/float")]
    public class floatVariable : ScriptableObject
    {
        public float Value;
        public void SetValue(float value) => Value = value;
        public void SetValue(floatVariable value) => Value = value.Value;
    }
}