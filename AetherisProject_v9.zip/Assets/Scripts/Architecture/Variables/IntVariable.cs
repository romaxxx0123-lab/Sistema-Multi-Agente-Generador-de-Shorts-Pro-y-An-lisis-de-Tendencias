using UnityEngine;

namespace Company.Games.ScriptableArchitecture
{
    [CreateAssetMenu(fileName = "New int Variable", menuName = "Architecture/Variables/int")]
    public class intVariable : ScriptableObject
    {
        public int Value;
        public void SetValue(int value) => Value = value;
        public void SetValue(intVariable value) => Value = value.Value;
    }
}