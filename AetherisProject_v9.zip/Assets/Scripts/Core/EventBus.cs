using System;
using System.Collections.Generic;

namespace Company.Games.Core
{
    public static class EventBus
    {
        private static readonly Dictionary<Type, List<Delegate>> _events = new Dictionary<Type, List<Delegate>>();

        public static void Subscribe<T>(Action<T> listener)
        {
            var type = typeof(T);
            if (!_events.ContainsKey(type)) _events[type] = new List<Delegate>();
            _events[type].Add(listener);
        }

        public static void Unsubscribe<T>(Action<T> listener)
        {
            var type = typeof(T);
            if (_events.ContainsKey(type)) _events[type].Remove(listener);
        }

        public static void Publish<T>(T eventData)
        {
            var type = typeof(T);
            if (_events.ContainsKey(type))
            {
                foreach (var listener in _events[type])
                {
                    ((Action<T>)listener).Invoke(eventData);
                }
            }
        }
    }
}