using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;

namespace Company.Games.Systems.Addressables
{
    public class AddressablesLoader : MonoBehaviour
    {
        public AssetReference assetReference;

        public void LoadAsset()
        {
            Addressables.LoadAssetAsync<GameObject>(assetReference).Completed += OnLoadCompleted;
        }

        private void OnLoadCompleted(AsyncOperationHandle<GameObject> handle)
        {
            if (handle.Status == AsyncOperationStatus.Succeeded)
            {
                Instantiate(handle.Result);
            }
        }
    }
}