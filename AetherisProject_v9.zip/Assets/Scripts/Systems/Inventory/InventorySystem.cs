using System.Collections.Generic;
using UnityEngine;

namespace Company.Games.Systems.Inventory
{
    [CreateAssetMenu(fileName = "New Inventory", menuName = "Systems/Inventory/Inventory Holder")]
    public class InventorySystem : ScriptableObject
    {
        public List<InventorySlot> slots = new List<InventorySlot>();
        public int capacity = 20;

        public bool AddItem(ItemDefinition item, int amount)
        {
            var slot = slots.Find(s => s.item == item);
            if (slot != null) { slot.amount += amount; return true; }
            if (slots.Count < capacity) { slots.Add(new InventorySlot { item = item, amount = amount }); return true; }
            return false;
        }
    }

    [System.Serializable]
    public class InventorySlot { public ItemDefinition item; public int amount; }
}