using UnityEngine;

namespace Company.Games.Systems.Inventory
{
    [CreateAssetMenu(fileName = "New Item", menuName = "Systems/Inventory/Item Definition")]
    public class ItemDefinition : ScriptableObject
    {
        public string id;
        public string displayName;
        public Sprite icon;
        public GameObject prefab;
    }
}