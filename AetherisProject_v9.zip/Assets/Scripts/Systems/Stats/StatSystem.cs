using UnityEngine;
using System.Collections.Generic;

namespace Company.Games.Systems.Stats
{
    public class StatSystem : MonoBehaviour
    {
        public List<Stat> stats = new List<Stat>();
        public float GetValue(string id) => stats.Find(s => s.id == id)?.Value ?? 0;
    }

    [System.Serializable]
    public class Stat
    {
        public string id;
        public float baseValue;
        public float Value => baseValue; // Expansion point for modifiers
    }
}