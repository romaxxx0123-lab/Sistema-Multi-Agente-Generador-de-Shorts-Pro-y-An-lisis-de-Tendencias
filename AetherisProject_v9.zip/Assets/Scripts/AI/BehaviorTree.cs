using UnityEngine;
using System.Collections.Generic;

namespace Company.Games.AI
{
    public abstract class Node { public abstract bool Execute(); }

    public class Selector : Node
    {
        private List<Node> nodes;
        public Selector(List<Node> nodes) { this.nodes = nodes; }
        public override bool Execute() { foreach (var node in nodes) if (node.Execute()) return true; return false; }
    }

    public class Sequence : Node
    {
        private List<Node> nodes;
        public Sequence(List<Node> nodes) { this.nodes = nodes; }
        public override bool Execute() { foreach (var node in nodes) if (!node.Execute()) return false; return true; }
    }

    public class BehaviorTreeAgent : MonoBehaviour
    {
        private Node root;
        void Update() { root?.Execute(); }
    }
}