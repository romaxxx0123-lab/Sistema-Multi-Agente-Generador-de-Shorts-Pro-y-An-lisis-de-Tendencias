using UnityEngine;
using Company.Games.Core;

namespace Company.Games.Managers
{
    public class WorldManager : Singleton<WorldManager>
    {
        [Header("World Settings")]
        public float gravityMultiplier = 1.0f;
        public int currentLevel = 1;

        void Start()
        {
            Debug.Log("World Manager active. Gravity: " + Physics.gravity);
        }

        public void NextLevel()
        {
            currentLevel++;
            Debug.Log("Proceeding to level " + currentLevel);
        }
    }
}