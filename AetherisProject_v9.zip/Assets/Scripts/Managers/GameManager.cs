using UnityEngine;
using Company.Games.Core;

namespace Company.Games.Managers
{
    public class GameManager : Singleton<GameManager>
    {
        public bool isGameOver = false;
        public float score = 0;
        public void AddScore(float amount) { score += amount; }
        public void GameOver() { isGameOver = true; Debug.Log("Game Over!"); }
    }
}