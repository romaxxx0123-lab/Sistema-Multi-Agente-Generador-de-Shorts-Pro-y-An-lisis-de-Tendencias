using Unity.Netcode;
using UnityEngine;

namespace Company.Games.Networking
{
    public class NetworkManagerUI : MonoBehaviour
    {
        [SerializeField] private UnityEngine.UI.Button serverBtn;
        [SerializeField] private UnityEngine.UI.Button hostBtn;
        [SerializeField] private UnityEngine.UI.Button clientBtn;

        private void Awake()
        {
            serverBtn.onClick.AddListener(() => NetworkManager.Singleton.StartServer());
            hostBtn.onClick.AddListener(() => NetworkManager.Singleton.StartHost());
            clientBtn.onClick.AddListener(() => NetworkManager.Singleton.StartClient());
        }
    }
}