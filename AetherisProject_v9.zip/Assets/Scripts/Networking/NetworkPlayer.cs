using Unity.Netcode;
using UnityEngine;

namespace Company.Games.Networking
{
    public class NetworkPlayer : NetworkBehaviour
    {
        private NetworkVariable<int> randomNumber = new NetworkVariable<int>(1, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Owner);

        public override void OnNetworkSpawn()
        {
            randomNumber.OnValueChanged += (int previousValue, int newValue) => {
                Debug.Log(OwnerClientId + "; randomNumber: " + newValue);
            };
        }

        void Update()
        {
            if (!IsOwner) return;
            if (Input.GetKeyDown(KeyCode.T)) randomNumber.Value = Random.Range(0, 100);
        }
    }
}