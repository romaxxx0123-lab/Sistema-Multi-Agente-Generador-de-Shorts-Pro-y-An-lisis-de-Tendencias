using UnityEditor;
using UnityEngine;

namespace Company.Games.EditorTools
{
    public class ProjectInitializer : EditorWindow
    {
        [MenuItem("Aetheris/Project Initializer")]
        public static void ShowWindow() => GetWindow<ProjectInitializer>("Aetheris Initializer");

        private void OnGUI()
        {
            GUILayout.Label("Aetheris Engine v9.0", EditorStyles.boldLabel);
            if (GUILayout.Button("Setup Project Structure"))
            {
                Debug.Log("Initializing Aetheris Architecture...");
                // Structural logic here
            }
        }
    }
}